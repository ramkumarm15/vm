﻿using AutoMapper;
using MovieTicketBooking.Business.Repository;
using MovieTicketBooking.Data.Models;
using System.Security.Cryptography;

namespace MovieTicketBooking.Business.Service
{
    public class UserService : IUserService
    {
        public UserService(IUserRepository repository, IMapper mapper)
        {
            Repository = repository;
            Mapper = mapper;
        }

        /// <summary>
        /// 
        /// </summary>
        public readonly IUserRepository Repository;

        /// <summary>
        /// 
        /// </summary>
        public readonly IMapper Mapper;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        public async Task<CreateResponse> CreateUser(UserDto data, bool isAdmin = false)
        {
            var newUser = Mapper.Map<User>(data);
            CreatePasswordHash(data.Password, out byte[] passwordHash, out byte[] passwordSalt);
            newUser.PasswordHash = passwordHash;
            newUser.PasswordSalt = passwordSalt;
            newUser.IsAdmin = isAdmin;
            newUser.Created = DateTime.Now;
            newUser.Updated = DateTime.Now;

            return await Repository.CreateUser(newUser);
        }

        public async Task<CreateResponse> UserPasswordUpdate(UserPasswordUpdate userPassword, string username)
        {
            var currentUser = await Repository.GetUserByUsername(username);

            if (currentUser == null)
            {
                var response = new CreateResponse()
                {
                    IsSuccess = false,
                    Message = "new password and confirm password not match"
                };
                return response;
            }

            return await Repository.UserPasswordUpdate(userPassword, currentUser);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        public async Task<CreateResponse> GenerateAuthToken(AuthenticationRequest user)
        {
            var response = new CreateResponse();

            if (!await Repository.CheckUserExistsByUsername(user.Username))
            {
                response.IsSuccess = true;
                response.Message = "No user found";
                return response;
            }

            var currentUser = await Repository.GetUserByUsername(user.Username);

            if (!await Repository.VerifyUserPassword(user.Password, currentUser))
            {
                response.IsSuccess = true;
                response.Message = "Password not match";
                return response;
            }

            var token = Repository.GenerateToken(currentUser, currentUser.IsAdmin ? "Admin" : "User");

            response.IsSuccess = true;
            response.Message = token;
            return response;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="password"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<bool> VerifyUserPassword(string password, User user)
        {
            return VerifyPasswordHash(password, user.PasswordHash, user.PasswordSalt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="password"></param>
        /// <param name="passwordHash"></param>
        /// <param name="passwordSalt"></param>
        private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="password"></param>
        /// <param name="passwordHash"></param>
        /// <param name="passwordSalt"></param>
        /// <returns></returns>
        private bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512(passwordSalt))
            {
                var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return computedHash.SequenceEqual(passwordHash);
            }
        }
    }
}
