﻿using AutoMapper;
using MovieTicketBooking.Business.Repository;
using MovieTicketBooking.Data.Models;
using System.Security.Cryptography;

namespace MovieTicketBooking.Business.Service
{
    public class UserService : IUserService
    {

        public readonly IUserRepository Repository;
        public readonly IMapper Mapper;

        public UserService(IUserRepository repository, IMapper mapper)
        {
            Repository = repository;
            Mapper = mapper;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        public async Task<CreateResponse> CreateUser(UserDto data, bool isAdmin = false)
        {
            User user = Mapper.Map<User>(data);
            CreatePasswordHash(data.Password, out byte[] passwordHash, out byte[] passwordSalt);
            user.PasswordHash = passwordHash;
            user.PasswordSalt = passwordSalt;
            user.IsAdmin = isAdmin;
            user.Created = DateTime.Now;
            user.Updated = DateTime.Now;

            return await Repository.CreateUser(user);
        }

        public async Task<CreateResponse> UserPasswordUpdate(UserPasswordUpdate userPassword, string username)
        {
            User currentUser = await Repository.GetUserByUsername(username);

            if (currentUser != null)
            {
                return await Repository.UserPasswordUpdate(userPassword, currentUser);
            }
            var response = new CreateResponse()
            {
                IsSuccess = false,
                Message = "New password not matched"
            };
            return response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        public async Task<CreateResponse> GenerateAuthToken(AuthenticationRequest user)
        {
            CreateResponse response = new CreateResponse();

            if (await Repository.CheckUserExistsByUsername(user.Username))
            {
                User currentUser = await Repository.GetUserByUsername(user.Username);

                if (await Repository.VerifyUserPassword(user.Password, currentUser))
                {
                    string token = Repository.GenerateToken(currentUser, currentUser.IsAdmin ? "Admin" : "User");

                    response.IsSuccess = true;
                    response.Message = token;
                    return response;
                }
                response.IsSuccess = false;
                response.Message = "Password not match";
                return response;
            }
            response.IsSuccess = true;
            response.Message = "No user found";
            return response;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="password"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<bool> VerifyUserPassword(string password, User user)
        {
            return VerifyPasswordHash(password, user.PasswordHash, user.PasswordSalt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="password"></param>
        /// <param name="passwordHash"></param>
        /// <param name="passwordSalt"></param>
        private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (HMACSHA512 hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="password"></param>
        /// <param name="passwordHash"></param>
        /// <param name="passwordSalt"></param>
        /// <returns></returns>
        private bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512(passwordSalt))
            {
                byte[] computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                return computedHash.SequenceEqual(passwordHash);
            }
        }
    }
}
