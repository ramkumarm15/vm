﻿using MovieTicketBooking.Data.Models;

namespace MovieTicketBooking.Business.Service
{
    public interface IUserService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="isAdmin"></param>
        /// <returns></returns>
        Task<CreateResponse> CreateUser(UserDto data, bool isAdmin = false);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userPassword"></param>
        /// <param name="username"></param>
        /// <returns></returns>
        Task<CreateResponse> UserPasswordUpdate(UserPasswordUpdate userPassword, string username);

        Task<CreateResponse> GenerateAuthToken(AuthenticationRequest user);
    }
}
