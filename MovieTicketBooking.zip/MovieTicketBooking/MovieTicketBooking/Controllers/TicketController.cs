﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieTicketBooking.Business.Service;
using MovieTicketBooking.Data.Models;
using MovieTicketBooking.Data.Models.Dto;
using System.Security.Claims;

namespace MovieTicketBooking.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = "UserOnly")]
    public class TicketController : ControllerBase
    {
        private readonly ITicketService _service;

        /// <summary>
        /// Constructor of Ticket Controller
        /// </summary>
        /// <param name="service"></param>
        public TicketController(ITicketService service)
        {
            _service = service;
        }

        /// <summary>
        /// Book an movie ticket for user
        /// </summary>
        /// <param name="model"></param>
        /// <param name="theatreId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("{theatreId}/Book")]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> TicketBook([FromBody] TicketDto model, [FromRoute] string theatreId)
        {
            string userId = User.FindFirstValue("Id");
            CreateResponse response = await _service.TicketBook(model, userId, theatreId);

            return response.IsSuccess ? Ok(response) : BadRequest(response);
        }
    }
}
