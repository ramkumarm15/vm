﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieTicketBooking.Business.Service;
using MovieTicketBooking.Data.Models;

namespace MovieTicketBooking.Controllers
{
    /// <summary>
    /// Constructor of Theatre Controller
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = "AdminOnly")]
    public class TheatreController : ControllerBase
    {
        private readonly ITheatreService service;

        /// <summary>
        /// 
        /// </summary>
        public TheatreController(ITheatreService _service)
        {
            service = _service;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("Reterive/All")]
        [AllowAnonymous]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetTheatre()
        {
            List<Theatre> theatre = await service.GetTheatre();

            return theatre.Count > 0 ? Ok(theatre) : BadRequest(theatre);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("Reterive/{id}")]
        [AllowAnonymous]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetTheatre([FromRoute] string id)
        {
            Theatre theatre = await service.GetTheatre(id);

            return theatre != null ? Ok(theatre) : BadRequest(theatre);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Add")]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> AddTheatre(TheatreDto model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid Data");
            }
            var response = await service.AddTheatre(model);

            return response.IsSuccess ? Ok(response) : BadRequest(response);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("Update/{id}")]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> UpdateTheatre(TheatreDto model, string id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid Data");
            }
            var response = await service.UpdateTheatre(model, id);

            return response.IsSuccess ? Ok(response) : BadRequest(response);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("Delete/{id}")]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(CreateResponse), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DeleteTheatre(string id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid Data");
            }
            var response = await service.DeleteTheatre(id);

            return response.IsSuccess ? Ok(response) : BadRequest(response);
        }
    }
}
