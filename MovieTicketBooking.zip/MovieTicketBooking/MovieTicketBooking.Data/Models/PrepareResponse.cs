﻿namespace MovieTicketBooking.Data.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class PrepareResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public bool IsSuccess { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string Message { get; set; }
    }
}
