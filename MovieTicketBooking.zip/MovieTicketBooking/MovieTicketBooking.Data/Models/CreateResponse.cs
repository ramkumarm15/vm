﻿namespace MovieTicketBooking.Data.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public bool IsSuccess { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string Message { get; set; }
    }
}
